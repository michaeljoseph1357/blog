AUTHOR = "Michael Boyle"
SITENAME = "Michael Boyle — AI Journey"
SITEURL = ""  # set to production URL on publish, e.g. "https://michaelboyle.ai"

PATH = "content"
TIMEZONE = "Europe/London"
DEFAULT_LANG = "en"
DEFAULT_DATE_FORMAT = "%%Y-%%m-%%d"

# URL / save paths (clean, SEO-friendly)
ARTICLE_URL = "blog/{date:%Y}/{date:%m}/{slug}/"
ARTICLE_SAVE_AS = "blog/{date:%Y}/{date:%m}/{slug}/index.html"
PAGE_URL = "{slug}/"
PAGE_SAVE_AS = "{slug}/index.html"
CATEGORY_SAVE_AS = ""
TAG_SAVE_AS = "tag/{slug}/index.html"
TAGS_SAVE_AS = "tags/index.html"
ARCHIVES_SAVE_AS = "blog/index.html"
YEAR_ARCHIVE_SAVE_AS = "blog/{date:%Y}/index.html"
MONTH_ARCHIVE_SAVE_AS = "blog/{date:%Y}/{date:%m}/index.html"

# Feed
FEED_ALL_RSS = "rss.xml"
CATEGORY_FEED_RSS = "category/{slug}.xml"
TRANSLATION_FEED_RSS = None
AUTHOR_FEED_RSS = None

# Pagination
DEFAULT_PAGINATION = 10

# Plugins (optional) — keeping stock for simplicity

# Theme: use Pelican's simple built-in theme but override CSS + a couple templates
THEME_TEMPLATES_OVERRIDES = ["theme_overrides/templates"]
STATIC_PATHS = ["images", "extra"]
EXTRA_PATH_METADATA = {
    "extra/favicon.ico": {"path": "favicon.ico"},
}
CUSTOM_CSS = "static/custom.css"  # injected via base template override

# Social/links
SOCIAL = (
    ("GitHub", "https://github.com/yourname"),
    ("LinkedIn", "https://www.linkedin.com/in/yourprofile/"),
)

# Jinja env
JINJA_ENVIRONMENT = {"trim_blocks": True, "lstrip_blocks": True}
