from pelicanconf import *

SITEURL = "https://example.com"  # <-- change to your domain
RELATIVE_URLS = False
FEED_ALL_RSS = "rss.xml"
DELETE_OUTPUT_DIRECTORY = True
