Title: About
Slug: about

I'm Michael Boyle — documenting a practical AI engineering journey while balancing life and valuation work.

**Now:** building small, real tools; writing concise notes; shipping every week.
