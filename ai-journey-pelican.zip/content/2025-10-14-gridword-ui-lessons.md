Title: Shipping GridWord v2 — UI lessons from Gradio
Date: 2025-10-14
Tags: UX, Gradio, Product
Summary: Calmer visuals, fewer layout shifts, better readability.

- Reduced color noise, increased spacing
- Kept critical info above the fold on a 13" screen
- Fixed card heights to avoid layout jumps
